package transferkfaka

import (
	"context"
	"fmt"
	"git/logTransfer/es"
	"time"

	"github.com/Shopify/sarama"
)

type Data struct {
	Data string `json:"data"`
}

var (
	consumer    sarama.Consumer //声明一个全局的连接kafka的消费者
	LogDatachan chan *string    //用来存储从kafka中取出来的日志
)

//初始化kafka连接
func Init(addr []string) (err error) {
	consumer, err = sarama.NewConsumer(addr, nil)
	if err != nil {
		fmt.Printf("fail to start consumer, err:%v\n", err)
		return
	}
	fmt.Println("connect kafka suncess")
	LogDatachan = make(chan *string, 100000)
	return
}

//将数据从kafka中取出来，存入一个通道中
func GetLog(topic string) {
	partitionList, err := consumer.Partitions(topic) // 根据topic取到所有的分区
	if err != nil {
		fmt.Printf("fail to get list of partition:err%v\n", err)
		return
	}
	fmt.Println(partitionList)

	for partition := range partitionList { // 遍历所有的分区
		// 针对每个分区创建一个对应的分区消费者
		pc, err := consumer.ConsumePartition(topic, int32(partition), sarama.OffsetNewest)
		if err != nil {
			fmt.Printf("failed to start consumer for partition %d,err:%v\n", partition, err)
			return
		}
		defer pc.AsyncClose()
		// 异步从每个分区消费信息

		go SendToChan(topic, pc) //将日志发送到ES

	}
	select {}
}

func SendToChan(topic string, pc sarama.PartitionConsumer) {
	for msg := range pc.Messages() {
		fmt.Printf("Partition:%d Offset:%d Key:%v Value:%v\n", msg.Partition, msg.Offset, msg.Key, string(msg.Value))
		//发送到logdatachan通道中
		var data = string(msg.Value)
		LogDatachan <- &data

	}
}

func SendToEs(indexstr, typesttr string) {
	client, err := es.Init()
	if err != nil {
		fmt.Println("初始化ES失败，err", err)
		return
	}
	for {
		select {
		case data := <-LogDatachan:
			//fmt.Println(logdata.topic)
			//fmt.Println(string(logdata.data))
			p1 := Data{Data: *data}
			put1, err := client.Index().
				Index(indexstr).
				Type(typesttr).
				BodyJson(p1).
				Do(context.Background())
			if err != nil {
				// Handle error
				fmt.Println("发送日志到ESS失败，err:", err)
				return
			}
			fmt.Printf("Indexed web_logs %s to index %s, type %s\n", put1.Id, put1.Index, put1.Type)

		default:
			time.Sleep(time.Millisecond * 500)
		}
	}
}

// func main() {
// 	Init([]string{"127.0.0.1:9092"})
// 	go SendToEs("logagent", "web_log6")
// 	GetLog("web_log6")

// }
