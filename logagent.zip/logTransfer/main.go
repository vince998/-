package main

import (
	"fmt"
	"git/logTransfer/config"
	"git/logTransfer/transferkfaka"

	"gopkg.in/ini.v1"
)

func main() {

	//1、加载配置文件
	var cfg config.LogTransFerCfg
	ini.MapTo(&cfg, "./config/config.ini") //将config中的配置映射到cfg结构体中
	//fmt.Println(cfg)
	//2、初始化kafka
	err := transferkfaka.Init([]string{cfg.KafkaCfg.Address})
	if err != nil {
		fmt.Println("初始化kafka失败,err:", err)
		return
	}
	//初始化ES,并将读取到的日志推送到ES
	go transferkfaka.SendToEs(cfg.ESCfg.Index, cfg.ESCfg.Type) //开一个goroutine专门推送日志到ES

	//从kafka中将对应topic中的日志读取出来
	transferkfaka.GetLog(cfg.KafkaCfg.Topic)
}
