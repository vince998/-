package config

type LogTransFerCfg struct {
	KafkaCfg `ini:"kafka"`
	ESCfg    `ini:"es"`
}

type KafkaCfg struct {
	Address string `ini:"address"`
	Topic   string `ini:"topic"`
}

type ESCfg struct {
	Address string `ini.v1:"address"`
	Index   string `ini:"index"`
	Type    string `ini:"type"`
}
