//使用etcd存储日志配置

package etcdlog

import (
	"context"
	"encoding/json"
	"time"

	clientv3 "go.etcd.io/etcd/clientv3"
)

var client *clientv3.Client

type LogEntry struct {
	Path  string `json:"path"`
	Topic string `json:"topic"`
}

//初始化etc
func Init(addr string) (err error) {
	//初始化etcd
	client, err = clientv3.New(clientv3.Config{
		Endpoints:   []string{addr},
		DialTimeout: 5 * time.Second,
	})
	if err != nil {
		// handle error
		return
	}
	return
}

//从etcd中根据key获取配置
func GetConf(key string) (logentrys []*LogEntry, err error) {
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*5)
	resp, err := client.Get(ctx, key)
	cancel()
	if err != nil {
		return
	}
	for _, ev := range resp.Kvs {
		err = json.Unmarshal(ev.Value, &logentrys)
		if err != nil {
			return
		}
	}
	return
}

func WatchConf(addr, key string) (rch clientv3.WatchChan, err error) {
	client, err = clientv3.New(clientv3.Config{
		Endpoints:   []string{addr},
		DialTimeout: 5 * time.Second,
	})
	if err != nil {
		// handle error
		return
	}
	rch = client.Watch(context.Background(), key)
	return

}

// func main() {
// 	Init("127.0.0.1:2379")

// 	// put
// 	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
// 	jsonkey := `[{"path":"D: mp\\kafka-logs\\web4_log-0","topic":"web_log"},{"path":"D: mp\\kafka-logs\\web4_log-0","topic":"web_log"}]
// `
// 	_, err := client.Put(ctx, "test", jsonkey)
// 	cancel()
// 	if err != nil {
// 		fmt.Printf("put to etcd failed, err:%v\n", err)
// 		return
// 	}

// 	logentrys, err := GetConf("test")
// 	if err != nil {
// 		fmt.Printf("get from etcd failed, err:%v\n", err)
// 		return
// 	}
// 	for i, v := range logentrys {
// 		fmt.Println(i, v)
// 	}
// }
