// package main

// import (
// 	"fmt"
// 	"git/logagent/config"
// 	"git/logagent/etcdlog"
// 	"git/logagent/kafka"
// 	"git/logagent/taillog"
// 	"time"
// )

// func run(topic string) {

// 	lines := taillog.ReadChan()
// 	//死循环，因为这是一个工具类的脚本，可以手动停止
// 	for {
// 		select {
// 		//1、读取日志
// 		case line := <-lines:
// 			//2、将日志发送到kafka
// 			kafka.SendToKafka(topic, line.Text)
// 		default:
// 			//如果读不到消息，就暂时睡眠一分钟
// 			time.Sleep(time.Second)
// 		}

// 	}

// }

// func main() {
// 	//初始化加载配置文件
// 	k, e, err := config.Init()
// 	if err != nil {
// 		fmt.Println("初始化配置文件失败，err:", err)
// 		return
// 	}

// 	// //1、初始化tail
// 	// err = taillog.Init("./my.log")
// 	// if err != nil {
// 	// 	fmt.Println("初始化tail失败，err:", err)
// 	// 	return
// 	// }
// 	//2、初始化kafka
// 	err = kafka.Init([]string{k.Addr})
// 	if err != nil {
// 		fmt.Println("初始化kafka失败，err:", err)
// 		return
// 	}

// 	//初始化etcd
// 	err = etcdlog.Init(e.Addr)
// 	if err != nil {
// 		fmt.Println("初始化etcd失败，err:", err)
// 		return
// 	}

// 	//从etcd获取配置信息
// 	logentrys, err := etcdlog.GetConf(e.Topic)
// 	if err != nil {
// 		fmt.Println("初始化etcd失败，err:", err)
// 		return
// 	}
// 	for i, v := range logentrys {
// 		fmt.Println(i, v)
// 	}

// 	// run(k.Topic)

// }