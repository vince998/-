package main

import (
	"git/logagent/taillog"
	"sync"
)

var wg sync.WaitGroup

func main() {
	taillog.Run()
	//taillog.WatchConf()
}
