// //使用tail从日志文件中将日志读取出来

package taillog

import (
	"context"
	"fmt"
	"git/logagent/config"
	"git/logagent/etcdlog"
	"git/logagent/kafka"
	"sync"
	"time"

	"github.com/hpcloud/tail"
)

//Tailtask ：一个日志收集任务
type Tailtask struct {
	path       string
	topic      string
	tails      *tail.Tail
	ctx        context.Context
	cancelFunc context.CancelFunc
}

type logData struct {
	topic string
	data  string
}

//声明一个用来存放tail从文件中读取出来日志的通道
var (
	logDatachan chan *logData
	wg          sync.WaitGroup
)

//初始化tail
func Init(filename string) (tails *tail.Tail, err error) {
	config := tail.Config{
		ReOpen:    true,                                 //重新打开
		Follow:    true,                                 //是否跟随
		Location:  &tail.SeekInfo{Offset: 0, Whence: 2}, //从文件哪个地方开始读
		MustExist: false,                                //文件不存在不报错
		Poll:      true,
	}
	//使用tail的配置和文件名
	tails, err = tail.TailFile(filename, config)
	if err != nil {
		return tails, err
	}
	return tails, err
}

//从Etcd拉取到本机器需要的配置存储到taillogMgr结构体中
func GetEtcConf() {
	//初始化配置
	cfg, err := config.Init()
	if err != nil {
		fmt.Println("初始化配置失败，err:", err)
		return
	}

	//初始化kafka
	kafka.Init([]string{cfg.Kafkaconf.Addr})

	//初始化etcd
	err = etcdlog.Init(cfg.Etcdconf.Addr)
	if err != nil {
		fmt.Println("初始化etcd失败，err:", err)
		return
	}

	//从Etcd拉取到本机器需要的配置
	tskMgr.logEntry, err = etcdlog.GetConf(cfg.Etcdconf.Key)
	if err != nil {
		fmt.Println("初始化etcd失败，err:", err)
		return
	}
	//初始化tskMap
	tskMgr.tskMap = make(map[string]*Tailtask, 16)
	//初始化消息通道
	logDatachan = make(chan *logData, cfg.Kafkaconf.Chanmaxsize)

}

//创建tailtask
func NewTailTask() {
	for _, v := range tskMgr.logEntry {
		//开始创建taild对象，有一个日志路径，就需要创建一个对应的tail去读取日志
		tail, err := Init(v.Path)
		if err != nil {
			fmt.Println("初始化tail错误，err:", err)
		}
		ctx, cancel := context.WithCancel(context.Background())
		//声明一个Tailtask结构体，用来存储tail任务的信息
		tailtask := Tailtask{
			path:       v.Path,
			topic:      v.Topic,
			tails:      tail,
			ctx:        ctx,
			cancelFunc: cancel,
		}
		key := v.Path + v.Topic
		tskMgr.tskMap[key] = &tailtask

	}
}

//将读取出来的日志存入通道中logDataChan
func (t Tailtask) sendtochan(ctx context.Context) {
	defer wg.Done()
	var logdata logData
	for {
		select {
		case <-t.ctx.Done():
			return
		case line := <-t.tails.Lines:
			logdata.topic = t.topic
			logdata.data = line.Text
			logDatachan <- &logdata
		default:
			time.Sleep(time.Millisecond * 500)

		}
	}

}

//把日志从通道中取出发送到kafka
func sendtokafka() {
	defer wg.Done()
	for {
		select {
		case logmsg := <-logDatachan:
			//将消息发送到kafka
			kafka.SendToKafka(logmsg.topic, logmsg.data)
		default:
			time.Sleep(time.Millisecond * 500)
		}
	}
}

func Run() {
	GetEtcConf()
	NewTailTask()
	wg.Add(1)
	go sendtokafka()
	//遍历tails对象，每有一个tailobj就开启一个goroutine
	for _, t := range tskMgr.tskMap {
		wg.Add(1)
		go t.sendtochan(t.ctx)
	}

	//监听配置变化
	runwatch()

	wg.Wait()
}

// //根据etcd中获取到需要读取多少个log文件，就创建多少个tail对象
// //每个日志对应一个tail对象
// func CreateTailObj() (tailobj []*Tailtask, err error) {
// 	//tailobj = make([]*Tailtask, 0, 100)
// 	//初始化配置文件
// 	logentrys, err := etcdlog.GetConf(cfg.Etcdconf.Key)
// 	if err != nil {
// 		fmt.Println("初始化etcd失败，err:", err)
// 		return
// 	}

// 	//初始化etcd
// 	err = etcdlog.Init(e.Addr)
// 	if err != nil {
// 		fmt.Println("初始化etcd失败，err:", err)
// 		return
// 	}

// 	//从etcd获取配置信息
// 	logentrys, err := etcdlog.GetConf(e.Key)
// 	if err != nil {
// 		fmt.Println("初始化etcd失败，err:", err)
// 		return
// 	}
// 	//fmt.Println(logentrys)
// 	for _, v := range logentrys {
// 		//	fmt.Println(v.Path, v.Topic)
// 		tail, err := Init(v.Path)
// 		if err != nil {
// 			fmt.Println("初始化tail错误，err:", err)
// 		}
// 		tailobj = append(tailobj, &Tailtask{
// 			path:  v.Path,
// 			topic: v.Topic,
// 			tails: tail,
// 		})
// 	}
//初始化消息通道
//fmt.Println(k.Chanmaxsize)
// logDatachan = make(chan *logData, k.Chanmaxsize)
// go SendToKafka()
// err = kafka.Init([]string{k.Addr})
// if err != nil {
// 	fmt.Println("初始化kafka失败，err:", err)
// 	return
// }

// 	return
// }

// //读取日志内容
// // func ReadChan() <-chan *tail.Line {
// // 	return tails.Lines
// // }

// //将消息发送到kafka
// func SendToChan() {

// 	tailobje, err := CreateTailObj()
// 	if err != nil {
// 		return
// 	}
// 	for _, tailobj := range tailobje {
// 		fmt.Println(tailobj, 1111)
// 		//没有一个tailobj就在后台起一个goroutine
// 		go SendChan(tailobj)

// 	}

// }

// func SendChan(tail *Tailtask) {
// 	var logdata logData
// 	for {
// 		//fmt.Println(tail.topic)
// 		select {
// 		//1、读取日志
// 		case line := <-tail.tails.Lines:
// 			//2、将日志先写入logDatachan通道中
// 			//fmt.Println(tail.topic)
// 			//fmt.Println(line.Text)

// 			logdata.topic = tail.topic
// 			logdata.Data = line.Text
// 			logDatachan <- &logdata
// 		default:
// 			//如果读不到消息，就暂时睡眠一分钟
// 			time.Sleep(time.Millisecond * 500)
// 		}

// 	}
// }

// //将消息从logDatachan通道中取出来，发送到kafka
// func SendToKafka() {
// 	for {
// 		select {
// 		case msg := <-logDatachan:
// 			fmt.Println(msg.topic, msg.Data)
// 			kafka.SendToKafka(msg.topic, msg.Data)
// 		default:
// 			time.Sleep(time.Millisecond * 50)
// 		}
// 	}
// }

// func Run() {
// 	//CreateTailObj()
// 	SendToChan()
// }
