package taillog

import (
	"context"
	"encoding/json"
	"fmt"
	"git/logagent/config"
	"git/logagent/etcdlog"
	"time"
)

var tskMgr taillogMgr

type taillogMgr struct {
	logEntry    []*etcdlog.LogEntry
	tskMap      map[string]*Tailtask
	newConfChan chan []*etcdlog.LogEntry
}

//初始化
func WatchConf() (newconf []*etcdlog.LogEntry, err error) {
	defer wg.Done()
	cfg, err := config.Init()
	if err != nil {
		fmt.Println("监听的初始化配置失败，err:", err)
		return
	}

	rch, err := etcdlog.WatchConf(cfg.Etcdconf.Addr, cfg.Etcdconf.Key)
	if err != nil {
		fmt.Println("监听的初始化etcd失败，err:", err)
		return
	}

	//初始化保存新推送过来的配置的通道
	tskMgr.newConfChan = make(chan []*etcdlog.LogEntry, 16)

	for wresp := range rch {
		for _, ev := range wresp.Events {
			//fmt.Println("新配置过来了")
			//fmt.Printf("Type: %T Key:%s Value:%s\n", ev.Type, ev.Kv.Key, ev.Kv.Value)
			//1、配置为空，或者配置被全部删除的情况，需要将之前开启的tail全部关闭
			if string(ev.Kv.Value) == "" || ev.Type.String() == "DEL" {
				for _, t := range tskMgr.tskMap {
					t.cancelFunc()
				}

			} else {
				//2、不为空的情况下进行反序列化，然后将获得的配置信息存入newConfChan通道中
				err = json.Unmarshal(ev.Kv.Value, &newconf)
				if err != nil {
					return
				}
				tskMgr.newConfChan <- newconf
			}

		}
	}
	return
}

func tailmgr() {
	defer wg.Done()
	for {
		select {
		case newconf := <-tskMgr.newConfChan:

			//fmt.Println("新配置过来了11111")

			//新增配置
			for _, v := range newconf {
				key := v.Path + v.Topic
				_, ok := tskMgr.tskMap[key]
				fmt.Println(3333333, ok)
				if !ok {
					ctx, cancel := context.WithCancel(context.Background())
					tail, err := Init(v.Path)
					if err != nil {
						break
					}
					tailtask := Tailtask{
						path:       v.Path,
						topic:      v.Topic,
						tails:      tail,
						ctx:        ctx,
						cancelFunc: cancel,
					}
					tskMgr.tskMap[key] = &tailtask
					wg.Add(1)
					go tailtask.sendtochan(tailtask.ctx)

				}
			}

			//新配置中有些旧的配置已经被删除，需要关闭掉对应的goroutine
			for k, t := range tskMgr.tskMap {
				isDelete := true
				for _, v := range newconf {
					key := v.Path + v.Topic
					if k == key {
						isDelete = false
					}
				}
				if isDelete {
					t.cancelFunc()
					fmt.Println("删除这个路径", t.path)
					delete(tskMgr.tskMap, k)
				}
			}

		default:
			time.Sleep(time.Second * 10)
		}
	}
}

func runwatch() {
	wg.Add(2)
	go WatchConf()
	go tailmgr()
}

// func get() {
// 	for k, v := range tskMgr.tskMap {
// 		fmt.Println(k, v)
// 	}
// }

// cli, err := clientv3.New(clientv3.Config{
// 		Endpoints:   []string{"127.0.0.1:2379"},
// 		DialTimeout: 5 * time.Second,
// 	})
// 	if err != nil {
// 		fmt.Printf("connect to etcd failed, err:%v\n", err)
// 		return
// 	}
// 	fmt.Println("connect to etcd success")
// 	defer cli.Close()
// 	// watch key:q1mi change
// 	rch := cli.Watch(context.Background(), "q1mi") // <-chan WatchResponse
// 	for wresp := range rch {
// 		for _, ev := range wresp.Events {
// 			fmt.Printf("Type: %s Key:%s Value:%s\n", ev.Type, ev.Kv.Key, ev.Kv.Value)
// 		}
// 	}
