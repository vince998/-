package config

import (
	"gopkg.in/ini.v1"
)

//kafka配置
type Kafka struct {
	Addr        string `init："addr"`
	Topic       string `init "topic"`
	Chanmaxsize uint   `init "chanmaxsize"`
}

type Etcdlog struct {
	Addr string `ini："addr"`
	Key  string `ini "key"`
}

type Cfg struct {
	Kafkaconf Kafka
	Etcdconf  Etcdlog
}

var cfg Cfg

func Init() (cfg Cfg, err error) {
	cfgconf, err := ini.Load("./config/config.ini")
	if err != nil {
		return
	}
	//获取kafka配置
	kafka_session, err := cfgconf.GetSection("kafuka")
	if err != nil {
		return
	}
	cfg.Kafkaconf.Addr = kafka_session.Key("addr").String()
	cfg.Kafkaconf.Topic = kafka_session.Key("topic").String()
	cfg.Kafkaconf.Chanmaxsize, err = kafka_session.Key("chan_max_size").Uint()
	if err != nil {
		return
	}

	//获取etcd配置
	etcd_session, err := cfgconf.GetSection("etcd")
	if err != nil {
		return
	}

	cfg.Etcdconf.Addr = etcd_session.Key("addr").String()
	cfg.Etcdconf.Key = etcd_session.Key("key").String()
	return

}
